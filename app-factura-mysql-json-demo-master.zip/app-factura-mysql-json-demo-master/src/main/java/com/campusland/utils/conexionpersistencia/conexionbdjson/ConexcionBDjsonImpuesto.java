package com.campusland.utils.conexionpersistencia.conexionbdjson;

import com.campusland.respository.models.Factura;

public class ConexcionBDjsonImpuesto extends ConexionBDJsonBase<Factura> {
    private static ConexcionBDjsonImpuesto conexionImpuestos;

    private ConexcionBDjsonImpuesto() {
        super("impuestos.json");
    }

    public static ConexcionBDjsonImpuesto getConexion() {
        if (conexionImpuestos != null) {
            return conexionImpuestos;
        } else {
            conexionImpuestos = new ConexcionBDjsonImpuesto();
            return conexionImpuestos;

        }
    }
}