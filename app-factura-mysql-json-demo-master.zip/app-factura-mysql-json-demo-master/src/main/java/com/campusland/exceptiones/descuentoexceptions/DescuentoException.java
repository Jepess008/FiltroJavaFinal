package com.campusland.exceptiones.descuentoexceptions;

public class DescuentoException extends Exception {
    public DescuentoException(String mensaje){
        super(mensaje);
    }
}
