package com.campusland.exceptiones.descuentoexceptions;

public class DescuentoNullException extends Exception {
    public DescuentoNullException(String mensaje){
        super(mensaje);
    }
}
