package com.campusland.exceptiones.clienteexceptions;

public class ClienteException extends Exception {

    public ClienteException(String mensaje){
        super(mensaje);
    }
    
}
