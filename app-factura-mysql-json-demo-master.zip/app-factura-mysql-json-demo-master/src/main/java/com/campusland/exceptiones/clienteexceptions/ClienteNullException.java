package com.campusland.exceptiones.clienteexceptions;

public class ClienteNullException extends ClienteException{

    public ClienteNullException(String mensaje){
        super(mensaje);
    }
    
}
