package com.campusland.views;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;

import com.campusland.exceptiones.facturaexceptions.FacturaExceptionInsertDataBase;
import com.campusland.respository.models.Cliente;
import com.campusland.respository.models.Descuento;
import com.campusland.respository.models.Factura;
import com.campusland.respository.models.ItemFactura;
import com.campusland.respository.models.Producto;
import com.campusland.utils.conexionpersistencia.conexionbdmysql.ConexionBDMysql;


public class ViewFactura extends ViewMain {

    

    public static void startMenu() {

        int op = 0;

        do {

            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearFactura();
                    break;
                case 2:
                    listarFactura();
                    break;
                case 3:
                    generar();
                    break;
                case 4:
                    informeTotal();
                    break;
                case 5:
                    clientesPorCompra();
                    break;
                case 6:
                    productoMasVendido();
                    break;   
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 7);

    }

    public static int mostrarMenu() {
        System.out.println("----Menu--Factura----");
        System.out.println("1. Crear factura.");
        System.out.println("2. Listar factura.");
        System.out.println("3. Generar archivo Dian por año");
        System.out.println("4. Informe total de ventas, descuentos, e impuestos");
        System.out.println("5. Listado descendente clientes por compras");
        System.out.println("6. Listado descendente producto mas vendido");
        System.out.println("7. Salir ");
        return leer.nextInt();
    }

    public static void listarFactura() {
        System.out.println("Lista de Facturas");
        for (Factura factura : serviceFactura.listar()) {
            factura.display();
            System.out.println();
        }
    }

    public static void crearFactura() {
        System.out.println("-- Creación de Factura ---");

        Cliente cliente;
        do {
            cliente = ViewCliente.buscarGetCliente();
        } while (cliente == null);

        Factura factura = new Factura(LocalDateTime.now(), cliente);
        System.out.println("-- Se creó la factura -----------------");
        System.out.println("-- Seleccione los productos a comprar por código");

        do {
            Producto producto = ViewProducto.buscarGetProducto();

            if (producto != null) {
                System.out.print("Cantidad: ");
                int cantidad = leer.nextInt();
                ItemFactura item = new ItemFactura(cantidad, producto);
                factura.agregarItem(item);

                System.out.println("Agregar otro producto: si o no");
                String otroItem = leer.next();
                if (!otroItem.equalsIgnoreCase("si")) {
                    break;
                }
            }

        } while (true);

    /*     System.out.println("¿Desea ingresar descuentos? (si/no)");
        String respuesta = leer.next();
        if (respuesta.equalsIgnoreCase("si")) {
            do {
                System.out.print("Tipo de descuento: ");
                String tipoDescuento = leer.nextLine();
                System.out.print("Condiciones: ");
                String condiciones = leer.nextLine();
                System.out.print("Monto o porcentaje: ");
                int montoPorcentaje = leer.nextInt();
                System.out.print("Estado: ");
                String estado = leer.nextLine();
                Descuento descuento = new Descuento(tipoDescuento, condiciones,montoPorcentaje, estado);
                factura.agregarDescuento(descuento);

                System.out.println("Agregar otro descuento: si o no");
                respuesta = leer.next();
                if (!respuesta.equalsIgnoreCase("si")) {
                    break;
                }
            } while (true);
    } */



        

        try {
            serviceFactura.crear(factura);
            System.out.println("Se creó la factura");
            factura.display();
        } catch (FacturaExceptionInsertDataBase e) {
            System.out.println(e.getMessage());
        }
    }

    public static void  generar(){
        System.out.println("F");
    }

    public static void informeTotal(){
        System.out.println("ok");
    }

    
    
    
    public static void clientesPorCompra() {
        try (Connection connection = ConexionBDMysql.getInstance();
            Statement statement = connection.createStatement()) {
            String sqlQuery = "SELECT c.nombre, c.apellido, SUM(IFNULL(i.importe, 0)) AS total_gastado " +
                            "FROM cliente c " +
                            "LEFT JOIN factura f ON c.id = f.cliente_id " +
                            "LEFT JOIN item_factura i ON f.numeroFactura = i.factura_numeroFactura " +
                            "GROUP BY c.nombre, c.apellido " +
                            "ORDER BY total_gastado DESC";
            try (ResultSet resultSet = statement.executeQuery(sqlQuery)) {
                System.out.println("Listado descendente de clientes por compras:");
                System.out.printf("%-20s %-20s %-20s%n", "Nombre", "Apellido", "Total Gastado");
                while (resultSet.next()) {
                    String nombre = resultSet.getString("nombre");
                    String apellido = resultSet.getString("apellido");
                    double totalGastado = resultSet.getDouble("total_gastado");
                    System.out.printf("%-20s %-20d%n", nombre, apellido, totalGastado);
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    
        public static void productoMasVendido() {
            try (Connection connection = ConexionBDMysql.getInstance();
                Statement statement = connection.createStatement()) {
                String sqlQuery = "SELECT p.nombre AS producto, " +
                                "SUM(i.cantidad) AS total_vendido " +
                                "FROM producto p " +
                                "JOIN item_factura i ON p.codigo = i.producto_codigo " +
                                "GROUP BY p.nombre " +
                                "ORDER BY total_vendido DESC";
                try (ResultSet resultSet = statement.executeQuery(sqlQuery)) {
                    System.out.println("Listado descendente de productos más vendidos:");
                    System.out.printf("%-20s %-20s%n", "Producto", "Total Vendido");
                    while (resultSet.next()) {
                        String nombreProducto = resultSet.getString("producto");
                        int totalVendido = resultSet.getInt("total_vendido");
                        System.out.printf("%-20s %-20d%n", nombreProducto, totalVendido);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    






