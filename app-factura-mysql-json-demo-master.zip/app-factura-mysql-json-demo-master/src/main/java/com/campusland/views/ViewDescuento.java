package com.campusland.views;

import com.campusland.exceptiones.descuentoexceptions.DescuentoNullException;
import com.campusland.respository.models.Descuento;

public class ViewDescuento extends ViewMain {
    public static void startMenu() {

        int op = 0;

        do {

            op = mostrarMenu();
            switch (op) {
                case 1:
                    crearDescuento();
                    break;
                case 2:
                    listarDescuento();
                    break;
                case 3:                   
                    buscarDescuento();
                    break;
                case 4:
                    modificarDescuento();
                    break;
                case 5:
                    eliminarDescuento();
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } while (op >= 1 && op < 6);

    }

    public static int mostrarMenu() {
        System.out.println("----Menu--Producto----");
        System.out.println("1. Crear producto.");
        System.out.println("2. Listar producto.");
        System.out.println("3. Buscar producto.");
        System.out.println("4. Modificar producto.");
        System.out.println("5. Eliminar producto.");
        System.out.println("6. Salir ");
        return leer.nextInt();
    }

    public static void crearDescuento() {
        leer.nextLine();
        System.out.print("Tipo de Descuento: ");
        System.out.println("Ingrese la el tipo Descuento: ");
        System.out.println("PORCENTAJE");
        System.out.println("MONTO FIJO");
        String tipo_descuento = leer.nextLine();
        System.out.print("Condiciones del descuento:");
        String condiciones = leer.nextLine();
        System.out.print("Asigne el valor del porcentaje del descuento: ");
        int porcentaje = leer.nextInt();
        System.out.print("Estado del descuento: ");
        String estado=leer.nextLine();
        
        Descuento descuento= new Descuento(tipo_descuento,condiciones,porcentaje,estado);

        ServiceDescuento.crear(descuento);

    }

    public static void listarDescuento() {
        System.out.println("Lista de Descuentos");
        for (Descuento descuento : ServiceDescuento.listar()) {
            descuento.imprimir();
            System.out.println();
        }
    }

    public static void buscarDescuento() {  
        System.out.println("Busqueda del Descuento ");      
        System.out.print("id: ");
        int id = leer.nextInt();
        try {
            Descuento descuento = ServiceDescuento.porId(id);
            System.out.println("Lista de Descuentos");
            descuento.imprimir();
        } catch (DescuentoNullException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Descuento buscarGetDescuento() {
        System.out.println("Busqueda de Descuento ");
        System.out.print("Id: ");
        int id = leer.nextInt();
        try {
            return ServiceDescuento.porId(id);

        } catch (DescuentoNullException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    
    public static void modificarDescuento() {
        Descuento descuentoActual = buscarGetDescuento();
        leer.nextLine();
        if (descuentoActual != null) {
            System.out.println();
            descuentoActual.toString();

            System.out.println("Modificar Tipo: si o no? ");
            String opcion = leer.nextLine();

            if (opcion.equalsIgnoreCase("si")) {
                System.out.println("Tipo descuento: ");
                System.out.println("Ingrese la el tipo Descuento: ");
                System.out.println("PORCENTAJE");
                System.out.println("MONTO FIJO");
                String nuevoDescuento = leer.nextLine();
                descuentoActual.setTipo_descuento(nuevoDescuento);
            }
            System.out.println("Modificar condiciones del descuento venta: si o no? ");
            opcion = leer.nextLine();

            if (opcion.equalsIgnoreCase("si")) {
                System.out.println("Condiciones del Descuento: ");
                String nuevasCondiciones = leer.nextLine();
                descuentoActual.setCondiciones(nuevasCondiciones);
            }
            leer.nextLine();

            System.out.println("Modificar monto del porcentaje: si o no? ");
            opcion = leer.nextLine();

            if (opcion.equalsIgnoreCase("si")) {
                System.out.println("Porcentaje monto: ");
                int nuevoPorcentaje = leer.nextInt();
                descuentoActual.setId_descuento(nuevoPorcentaje);
            }
            leer.nextLine();

            System.out.println("Estado del Descuento: si o no? ");
            opcion = leer.nextLine();

            if (opcion.equalsIgnoreCase("si")) {
                System.out.println("Estado: ");
                String nuevoEstado = leer.nextLine();
                descuentoActual.setEstado(nuevoEstado);
            }

            ServiceDescuento.editar(descuentoActual);
        }
    }

    public static void eliminarDescuento() {       
        Descuento descuento = buscarGetDescuento();
        if (descuento != null) {
            ServiceDescuento.eliminar(descuento);
            System.out.println("El Descuento se elmino correctamente ");
        } else {
            System.out.println("Se presento un proplema y no se puedo eliminar el producto ");
        }

    }
}
