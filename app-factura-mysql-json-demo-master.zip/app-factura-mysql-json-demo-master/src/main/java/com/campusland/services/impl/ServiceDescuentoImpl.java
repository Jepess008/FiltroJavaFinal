package com.campusland.services.impl;

import java.util.List;

import com.campusland.exceptiones.descuentoexceptions.DescuentoNullException;
import com.campusland.respository.RepositoryDescuento;
import com.campusland.respository.models.Descuento;
import com.campusland.services.ServiceDescuento;

public class ServiceDescuentoImpl implements ServiceDescuento {

    private final RepositoryDescuento crudRepositoryDescuento;

    public ServiceDescuentoImpl(RepositoryDescuento crudRepositoryDescuento){
        this.crudRepositoryDescuento=crudRepositoryDescuento;
    }



    @Override
    public List<Descuento> listar() {
        return this.crudRepositoryDescuento.listar();
    }

    @Override
    public Descuento porId(int id) throws DescuentoNullException {
        Descuento descuento = this.crudRepositoryDescuento.porId(id);
        if (descuento != null) {
            return descuento;
        } else {
            throw new DescuentoNullException("No se encontro producto por codigo");
        }
    }

    @Override
    public void crear(Descuento descuento) {
        this.crudRepositoryDescuento.crear(descuento);
    }

    @Override
    public void editar(Descuento descuento) {
        this.crudRepositoryDescuento.editar(descuento);
    }

    @Override
    public void eliminar(Descuento descuento) {
        this.crudRepositoryDescuento.eliminar(descuento);
    }
    
}
