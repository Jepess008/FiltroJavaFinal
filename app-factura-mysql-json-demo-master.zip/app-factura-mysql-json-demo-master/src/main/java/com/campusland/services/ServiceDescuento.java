package com.campusland.services;

import java.util.List;

import com.campusland.exceptiones.descuentoexceptions.DescuentoNullException;
import com.campusland.respository.models.Descuento;

public interface ServiceDescuento {
    List<Descuento> listar();

    Descuento porId(int id) throws DescuentoNullException;

    void crear(Descuento descuento);

    void editar(Descuento descuento);

    void eliminar(Descuento descuento);
}
