package com.campusland.respository.models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Descuento {

    private int id_descuento;
    private String tipo_descuento;
    private String condiciones;
    private int monto_porcentaje;
    private String estado;
    private Factura factura;

    public Descuento(String tipo_descuento, String condiciones, int monto_porcentaje,String estado){
        this.tipo_descuento=tipo_descuento;
        this.condiciones=condiciones;
        this.monto_porcentaje=monto_porcentaje;
        this.estado=estado;
    }

    public void imprimir(){
        System.out.println("ID descuento: "+this.id_descuento);
        System.out.println("Tipo descuento: "+ this.tipo_descuento);
        System.out.println("Condiciones para su uso: "+this.condiciones);
        System.out.println("Monto del porcentaje: "+ this.monto_porcentaje);
        System.out.println("Estado del descuento: "+this.estado);
    }

    public double getImporteDescuento(){
        return this.monto_porcentaje*this.factura.getTotalFactura();
    }

}
