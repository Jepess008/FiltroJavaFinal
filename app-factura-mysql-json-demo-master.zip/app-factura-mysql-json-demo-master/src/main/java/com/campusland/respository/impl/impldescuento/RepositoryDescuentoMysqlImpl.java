package com.campusland.respository.impl.impldescuento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.campusland.respository.RepositoryDescuento;
import com.campusland.respository.models.Descuento;
import com.campusland.utils.conexionpersistencia.conexionbdmysql.ConexionBDMysql;

public class RepositoryDescuentoMysqlImpl implements RepositoryDescuento {

    private Connection getConnection() throws SQLException {
        return ConexionBDMysql.getInstance();
    }

    private Descuento crearDescuento(ResultSet rs) throws SQLException {
        Descuento descuento = new Descuento();
        descuento.setId_descuento(rs.getInt("id_descuento"));
        descuento.setTipo_descuento(rs.getString("tipo_descuento"));
        descuento.setCondiciones(rs.getString("condiciones"));
        descuento.setMonto_porcentaje(rs.getInt("porcentaje"));
        descuento.setEstado(rs.getString("estado"));
        
        return descuento;

    }

    @Override
    public List<Descuento> listar() {
        List<Descuento> listDescuentos = new ArrayList<>();

        try (Connection conn = getConnection();
            Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM descuento")) {
            while (rs.next()) {
                listDescuentos.add(crearDescuento(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listDescuentos;
    }

    @Override
    public Descuento porId(int id) {
        Descuento descuento = null;

        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM descuento WHERE id=?")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    descuento = crearDescuento(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return descuento;
    }

    @Override
    public void crear(Descuento descuento) {
        String sql = "INSERT INTO descuneto(tipo_descuento, condiciones,porcentaje,estado) VALUES(?,?,?,?)";

        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, descuento.getTipo_descuento());
            stmt.setString(2, descuento.getCondiciones());
            stmt.setInt(3, descuento.getMonto_porcentaje());
            stmt.setString(4, descuento.getEstado());           
            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void editar(Descuento descuento) {
        String sql = "UPDATE descuento SET tipo_descuento=?, condiciones=?,porcentaje=?,estado=? WHERE id_descuento=? ";

        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, descuento.getTipo_descuento());
            stmt.setString(2, descuento.getCondiciones());
            stmt.setInt(3, descuento.getMonto_porcentaje());
            stmt.setString(4, descuento.getEstado());
            stmt.setInt(5,descuento.getId_descuento());           
            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    public void eliminar(Descuento descuento) {
        try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM descuento WHERE id_descuento=?")) {
            stmt.setInt(1, descuento.getId_descuento());
            stmt.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    
}
